<?php
require_once (dirname(dirname(__FILE__)) . '/userhistory.class.php');
class UserHistory_mysql extends UserHistory {}