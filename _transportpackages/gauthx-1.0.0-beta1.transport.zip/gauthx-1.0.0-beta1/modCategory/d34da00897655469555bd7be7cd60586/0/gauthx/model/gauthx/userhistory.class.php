<?php
class UserHistory extends xPDOSimpleObject {}